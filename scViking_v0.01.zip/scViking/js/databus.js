import Pool from './base/pool'

let instance

/**
 * 全局状态管理器
 */
export default class DataBus {
  constructor() {
    if (instance) return instance

    instance = this

    this.pool = new Pool()

    this.reset()
  }

  reset() {
    this.frame = 0
    this.scoreSurvive = 0
    this.scoreKill=0
    this.animations = []
    this.enemys=[]
    this.bullets=[]
    this.heroBullets=[]
    this.gameOver = false
  }

  removeBullets(item){
    for (let i=0;i<this.bullets.length;i++){
      if (this.bullets[i]===item){
        this.bullets.splice(i,1)
      }
    }

    this.pool.recover('bullet',item)
  }

  removeHeroBullets(item){
    for (let i=0;i<this.heroBullets.length;i++){
      if (this.heroBullets[i]===item){
        this.heroBullets.splice(i,1)
      }
    }
    this.pool.recover('heroBullet',item)
  }

  removeEnemy1s(item){
    for (let i=0;i<this.enemys.length;i++){
      if (this.enemys[i]===item){
        this.enemys.splice(i,1)
      }
    }
    this.pool.recover('enemy1',item)
  }

  removeEnemy2s(item){
    for (let i=0;i<this.enemys.length;i++){
      if (this.enemys[i]===item){
        this.enemys.splice(i,1)
      }
    }
    this.pool.recover('enemy2',item)
  }

  removeEnemy3s(item){
    for (let i=0;i<this.enemys.length;i++){
      if (this.enemys[i]===item){
        this.enemys.splice(i,1)
      }
    }
    this.pool.recover('enemy3',item)
  }

  removeEnemy4s(item){
    for (let i=0;i<this.enemys.length;i++){
      if (this.enemys[i]===item){
        this.enemys.splice(i,1)
      }
    }
    this.pool.recover('enemy4',item)
  }
}
