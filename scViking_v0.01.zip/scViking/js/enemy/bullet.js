import Sprite from '../base/sprite'
import Databus from '../databus'
import * as BGInfo from '../runtime/background'

const BULLET_WIDTH=BGInfo.IMG_WIDTH/10
const BULLET_HEIGHT=BULLET_WIDTH

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

const BULLET_IMG_SRC='images/explosion19.png'

const databus=new Databus()

let _={
  speed:Symbol('speed')
}

export default class Bullet extends Sprite{
  constructor(){
    super(BULLET_IMG_SRC,BULLET_WIDTH,BULLET_HEIGHT)
  }

  init(x,y,speed,width,height){
    this.width=width
    this.height=height
    this.realX=x
    this.realY=y
    this.x=screenWidth*(this.realX-BGInfo.lt_X)/BGInfo.IMG_WIDTH-this.width/2
    this.y=screenHeight*(this.realY-BGInfo.lt_Y)/BGInfo.IMG_HEIGHT-this.height/2
    this[_.speed]=speed
    this.visible=true
    this.angle=0
  }

  update(){
    this.realX+=this[_.speed].sx
    this.realY+=this[_.speed].sy
    this.x=screenWidth*(this.realX-BGInfo.lt_X)/BGInfo.IMG_WIDTH-this.width/2
    this.y=screenHeight*(this.realY-BGInfo.lt_Y)/BGInfo.IMG_HEIGHT-this.height/2
    if (this.realX<0||this.realX>BGInfo.BG_WIDTH||this.realY<0||this.realY>BGInfo.BG_HEIGHT||this.visible==false){
      databus.removeBullets(this)
    }
  }

  setSrc(newImgSrc){
    this.img.src=newImgSrc
  }

  drawToCanvas(ctx) {
    if (!this.visible) return
    ctx.save()
    ctx.translate(this.x+this.width/2,this.y+this.height/2)
    ctx.rotate(this.angle)
    ctx.drawImage(
      this.img,
      -this.width/2,
      -this.height/2,
      this.width,
      this.height
    )
    ctx.restore()
  }
}