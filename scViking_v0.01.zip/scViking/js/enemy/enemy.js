import Sprite from '../base/sprite'
import Databus from '../databus'
import * as BGInfo from '../runtime/background'
import Animation from '../base/animation'

const databus=new Databus()

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

let _={
  route:Symbol('route')
}

export default class Enemy extends Animation{
  init(x,y,route,bulletSpped){
    this.realX=x
    this.realY=y
    this.x=screenWidth*(this.realX-BGInfo.lt_X)/BGInfo.IMG_WIDTH-this.width/2
    this.y=screenHeight*(this.realY-BGInfo.lt_Y)/BGInfo.IMG_HEIGHT-this.height/2
    this[_.route]=route
    this.bulletSpped=bulletSpped
    this.visible=true
    this.angle=0
    this.moveStop=false
    this.specialInit()
    this.initExplosionAnimation()
  }

  rnd(start,end){
    return Math.floor(Math.random()*(end-start+1)+start)
  }  

  update(){
    this.specialUpdate()
    if (this.moveStop) return
    let route=this[_.route]

    let k=2*route.a*route.dx+route.b

    let dx=route.speed/Math.sqrt(1+k*k)
    route.dx+=dx
    
    this.realX+=dx
    //以出生点为原点的x轴坐标
    let x=route.dx
    this.realY=route.yBirth+route.a*x*x+route.b*x+route.c

    this.angle=Math.atan(k)-3*Math.PI/2
    if (route.dx>0){
      this.angle+=Math.PI
    }

    this.x=screenWidth*(this.realX-BGInfo.lt_X)/BGInfo.IMG_WIDTH-this.width/2
    this.y=screenHeight*(this.realY-BGInfo.lt_Y)/BGInfo.IMG_HEIGHT-this.height/2
  }

  // 预定义爆炸的帧动画
  initExplosionAnimation() {
    const frames = []

    const EXPLO_IMG_PREFIX = 'images/explosion'
    const EXPLO_FRAME_COUNT = 19

    for (let i = 0; i < EXPLO_FRAME_COUNT; i++) {
      //变量和常量写到一起？
      frames.push(`${EXPLO_IMG_PREFIX + (i + 1)}.png`)
    }

    this.initFrames(frames)
  }

  specialInit(){
    
  }

  specialUpdate(){

  }

  shoot(){

  }

  drawToCanvas(ctx) {
    if (!this.visible) return
    ctx.save()
    ctx.translate(this.x+this.width/2,this.y+this.height/2)
    ctx.rotate(this.angle)
    ctx.drawImage(
      this.img,
      -this.width/2,
      -this.height/2,
      this.width,
      this.height
    )
    ctx.restore()
  }
}