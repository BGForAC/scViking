import Databus from '../databus'
import Bullet from '../enemy/bullet'
import Enemy from "../enemy/enemy"
import * as BGInfo from '../runtime/background'
import * as index from '../player/index'

const ENEMY_WIDTH=BGInfo.IMG_WIDTH/5
const ENEMY_HEIGHT=ENEMY_WIDTH*1

const BULLET1_WIDTH=BGInfo.IMG_WIDTH/10
const BULLET1_HEIGHT=BULLET1_WIDTH

const BULLET2_WIDTH=BGInfo.IMG_WIDTH/20
const BULLET2_HEIGHT=BULLET2_WIDTH*2

const ENEMY_IMG_SRC='images/enemy2.png'

const databus=new Databus()

export default class Enemy2 extends Enemy{
  constructor(){
    super(ENEMY_IMG_SRC,ENEMY_WIDTH,ENEMY_HEIGHT)
    this.stopAlready=false
    this.stopX=0
    this.endStopFrame=0
  }

  specialInit(){
    this.stopAlready=false
    this.stopX=0
    this.endStopFrame=0
    this.life=3
  }

  shoot(){
    //50%概率射击
    let isShoot=this.rnd(0,1)
    if (!isShoot) return;
    
    if (!this.moveStop) return

    let dx=BGInfo.player_X-this.realX
    let dy=BGInfo.player_Y-this.realY
    //统一angle到(0,2*PI)
    let angle1=Math.atan(dy/dx)
    if (dx<0){
      angle1+=Math.PI
    }else if(angle1<0){
      angle1+=Math.PI*2
    }
    let angle2=angle1+Math.PI/6
    let angle3=angle1-Math.PI/6
    
    const bullet1=databus.pool.getItemByClass('bullet',Bullet)
    bullet1.img.src="images/enemy2Bullet1.png"
    let direction1=index.speed(dx,dy,this.bulletSpped)
    bullet1.init(this.realX,this.realY,direction1,BULLET1_WIDTH,BULLET1_HEIGHT)

    bullet1.angle=angle1-Math.PI/2
    setTimeout(function(){
      databus.bullets.push(bullet1)
    },500)

    const bullet2=databus.pool.getItemByClass('bullet',Bullet)
    const bullet3=databus.pool.getItemByClass('bullet',Bullet)
    bullet2.img.src="images/enemy2Bullet2.png"
    bullet3.img.src="images/enemy2Bullet2.png"
    let direction2,direction3
    
    //在第二和第三象限
    if (angle2>Math.PI/2&&angle2<3*Math.PI/2){
      direction2=index.speed(-1,-1*Math.tan(angle2),this.bulletSpped)
    }else {
      direction2=index.speed(1,1*Math.tan(angle2),this.bulletSpped)
    }
    //在第二和第三象限
    if (angle3>Math.PI/2&&angle3<3*Math.PI/2){
      direction3=index.speed(-1,-1*Math.tan(angle3),this.bulletSpped)
    }else {
      direction3=index.speed(1,1*Math.tan(angle3),this.bulletSpped)
    }

    bullet2.init(this.realX,this.realY,direction2,BULLET2_WIDTH,BULLET2_HEIGHT)
    bullet2.angle=angle2-Math.PI/2

    bullet3.init(this.realX,this.realY,direction3,BULLET2_WIDTH,BULLET2_HEIGHT)
    bullet3.angle=angle3-Math.PI/2
  
    databus.bullets.push(bullet2)
    databus.bullets.push(bullet3)
  }

  specialUpdate(){
    //初始化暂停的位置
    if (this.stopX==0){
      this.stopX=this.rnd(BGInfo.BG_WIDTH/12,BGInfo.BG_WIDTH*11/12)
    }
    //如果Y轴下降到一定程度，则开始暂停
    if (this.realX-this.stopX<5&&this.realX-this.stopX>-5&&!this.stopAlready){
      this.moveStop=true
      this.stopAlready=true
      this.endStopFrame=databus.frame+this.rnd(600,1200)
    }
    if (this.moveStop){
      if (databus.frame>this.endStopFrame){
        this.moveStop=false
      }
    }
    if (this.realX<-this.width/2||this.realX>BGInfo.BG_WIDTH+this.width/2
      ||this.realY<-this.height/2||this.realY>BGInfo.BG_HEIGHT+this.height/2
      ||this.visible===false){
        if (this.visible==false){
          databus.scoreKill+=200
        }
      databus.removeEnemy2s(this)
    }
  }
}