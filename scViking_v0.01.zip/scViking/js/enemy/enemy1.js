import Databus from '../databus'
import Bullet from '../enemy/bullet'
import Enemy from "../enemy/enemy"
import * as BGInfo from '../runtime/background'
import * as index from '../player/index'

const ENEMY_WIDTH=BGInfo.IMG_WIDTH/6
const ENEMY_HEIGHT=ENEMY_WIDTH*4/3

const BULLET_WIDTH=BGInfo.IMG_WIDTH/10
const BULLET_HEIGHT=BULLET_WIDTH*3

const ENEMY_IMG_SRC='images/enemy1.png'

const databus=new Databus()

export default class Enemy1 extends Enemy{
  constructor(){
    super(ENEMY_IMG_SRC,ENEMY_WIDTH,ENEMY_HEIGHT)
  }

  specialInit(){
    this.life=1
  }

  shoot(){
    //50%概率射击
    let isShoot=this.rnd(0,1)
    if (!isShoot) return;
    
    const bullet1=databus.pool.getItemByClass('bullet',Bullet)
    bullet1.img.src='images/enemy1Bullet1.png'

    let dx=BGInfo.player_X-this.realX
    let dy=BGInfo.player_Y-this.realY

    let direction1=index.speed(dx,dy,this.bulletSpped)

    bullet1.init(this.realX,this.realY,direction1,BULLET_WIDTH,BULLET_HEIGHT)
    bullet1.angle=Math.PI/2-Math.atan(-dy/dx)
    if (dx>0){
      bullet1.angle+=Math.PI
    }

    databus.bullets.push(bullet1)
  }

  specialUpdate(){
    if (this.realX<-this.width/2||this.realX>BGInfo.BG_WIDTH+this.width/2
      ||this.realY<-this.height/2||this.realY>BGInfo.BG_HEIGHT+this.height/2
      ||this.visible===false){
        if (this.visible==false){
          databus.scoreKill+=100
        }
      databus.removeEnemy1s(this)
    }
  }
}