import Player from './player/index'
import BackGround from './runtime/background'
import GameInfo from './runtime/gameinfo'
import Music from './runtime/music'
import DataBus from './databus'
import Enemy1 from './enemy/enemy1'
import Enemy2 from './enemy/enemy2'
import Enemy3 from './enemy/enemy3'
import * as BGInfo from './runtime/background'

const ctx = canvas.getContext('2d')
const databus = new DataBus()

const enemyShootTime=75

const enemyBirthTime=300

const enemyTypeCount=3

const enemy1Speed=BGInfo.IMG_WIDTH/75
const enemy2Speed=BGInfo.IMG_WIDTH/100
const enemy3Speed=BGInfo.IMG_WIDTH/50

const enemy1BulletSpeed=BGInfo.IMG_WIDTH/100
const enemy2BulletSpeed=BGInfo.IMG_WIDTH/50
const enemy3BulletSpeed=BGInfo.IMG_WIDTH/75
//同组敌人生成的时间间隔
const enemy1CreateTime=50
const enemy2CreateTime=100
const enemy3CreateTime=30

//角色速度在index.js中，为常量DEFAULT_SPEED

const heroShootTime=20

let lastFrameTime
const targetFPS = 60;
const frameInterval = 1000 / targetFPS;

/**
 * 游戏主函数
 */

function rnd(start,end){
  return Math.floor(Math.random()*(end-start+1)+start)
}

export default class Main {
  constructor() {
    // 维护当前requestAnimationFrame的id
    this.aniId = 0

    this.restart()
  }

  restart() {
    databus.reset()

    canvas.removeEventListener(
      'touchstart',
      this.touchHandler
    )

    this.bg = new BackGround(ctx)
    this.player = new Player(ctx)
    this.gameinfo = new GameInfo()
    this.music = new Music()

    //判断每轮敌人的数量是否创建完毕
    this.isInitEnemyNumer=false
    //判断是否正在创建一轮的敌人
    this.isCreatingEnemy=false
    //一轮还需要生成的敌人数量
    this.createEnemyCount=0
    //一轮敌人的生成坐标
    this.enemyBirthX=0
    this.enemyBirthY=0
    //一轮敌人的运动轨迹
    this.enemyRoute={
      a:0,
      b:0,
      c:0,
      //x的偏移量
      dx:0,
      //移动速度
      speed:0,
      yBirth:0,
      xBirth:0
    }
    this.enemyType=1

    this.bindLoop = this.loop.bind(this)
    this.hasEventBind = false

    // 清除上一局的动画
    window.cancelAnimationFrame(this.aniId)

    this.aniId = window.requestAnimationFrame(
      this.bindLoop,
      canvas
    )
  }

  

  //敌人位置生成（根据背景图的大小生成）
  enemyGenerate(){
    if (databus.frame%enemyBirthTime===0){
      this.isCreatingEnemy=true
      this.enemyType=rnd(1,enemyTypeCount)
    }
    if (this.isCreatingEnemy){
      switch(this.enemyType){
        case 1:
          this.enemy1Generate()
          break
        case 2:
          this.enemy2Generate()
          break
        case 3:
          this.enemy3Generate()
          break
      }
    }
  }

  //返回一个Object，{routeA：轨迹二次函数的a，routeB：轨迹二次函数的b}
  //输入为以出生点为原点，二次函数最高点的在画面中的坐标( 百分比)，例:(0.4,0.2)
  createRoute(topX,topY){
    const width=BGInfo.BG_WIDTH
    const height=BGInfo.BG_HEIGHT
    let routeA=-1
    let routeB=-2*routeA*width*topX
    //X坐标已确定，开始确定Y坐标
    let multi=height*topY/(-routeB*routeB/4*routeA)
    routeA*=multi
    routeB*=multi
    return {
      routeA:routeA,
      routeB:routeB
    }
  }
  
  enemy1Generate(){
    const width=BGInfo.BG_WIDTH
    const height=BGInfo.BG_HEIGHT
    //生成敌人，如果敌人数量未确定则确定敌人数量，已确定则生成的敌人减少
    if (databus.frame%enemy1CreateTime===0){
      if (!this.isInitEnemyNumer){
         this.createEnemyCount=rnd(3,5)
         this.isInitEnemyNumer=true

         this.enemyBirthX=rnd(0,1)*width
         this.enemyBirthY=rnd(height/4,height/2)
         //以出生点为原点，二次函数最高点的在画面中的坐标( 百分比)
         let topX=rnd(2,3)/10
         let topY=rnd(1,2)/10
         let route=this.createRoute(topX,topY)
         this.enemyRoute={
           a:route.routeA,
           b:route.routeB,
           c:0,
           dx:0,
           speed:enemy1Speed,
           yBirth:this.enemyBirthY,
           xBirth:this.enemyBirthX
         }
         if (this.enemyBirthX==width){
           this.enemyRoute.speed*=-1
           this.enemyRoute.b*=-1
         }
      }
      this.createEnemyCount--
      if (this.createEnemyCount==0){
        this.isInitEnemyNumer=false
        this.isCreatingEnemy=false
      }
      //创建对象
      const enemy=databus.pool.getItemByClass('enemy1',Enemy1)

      let newRoute=Object.assign({},this.enemyRoute)

      enemy.init(
        this.enemyBirthX,
        this.enemyBirthY,
        newRoute,
        enemy1BulletSpeed
      )
      databus.enemys.push(enemy)
    }
  }

  
  enemy2Generate(){
    const width=BGInfo.BG_WIDTH
    const height=BGInfo.BG_HEIGHT
    //生成敌人，如果敌人数量未确定则确定敌人数量，已确定则生成的敌人减少
    if (databus.frame%enemy2CreateTime===0){
      if (!this.isInitEnemyNumer){
         this.isInitEnemyNumer=true
        //生成一个或两个敌人
         this.createEnemyCount=rnd(1,2)
         this.enemyBirthX=rnd(0,1)*width
         this.enemyBirthY=rnd(height/8,height/3)
         let topX=rnd(6,7)/10
         let topY=rnd(1,2)/10
         let route=this.createRoute(topX,topY)
         this.enemyRoute={
           a:route.routeA,
           b:route.routeB,
           c:0,
           dx:0,
           speed:enemy2Speed,
           yBirth:this.enemyBirthY,
           XBirth:this.enemyBirthX
         }
         if (this.enemyBirthX==width){
           this.enemyRoute.speed*=-1
           this.enemyRoute.b*=-1
         }
      }
      this.createEnemyCount--
      if (this.createEnemyCount==0){
        this.isInitEnemyNumer=false
        this.isCreatingEnemy=false
      }
      //创建对象
      const enemy=databus.pool.getItemByClass('enemy2',Enemy2)

      let newRoute=Object.assign({},this.enemyRoute)

      enemy.init(
        this.enemyBirthX,
        this.enemyBirthY,
        newRoute,
        enemy2BulletSpeed
      )
      databus.enemys.push(enemy)

      if (this.createEnemyCount==1){
        //第二架飞机从反方向出现（x只有0和width）
        this.enemyBirthX=(this.enemyBirthX+width)%(2*width)
        this.enemyBirthY=rnd(height/4,height/2)
        this.enemyRoute.speed*=-1
        this.enemyRoute.b*=-1
      }
    }
  }

  enemy3Generate(){
    const width=BGInfo.BG_WIDTH
    const height=BGInfo.BG_HEIGHT
    //生成敌人，如果敌人数量未确定则确定敌人数量，已确定则生成的敌人减少
    if (databus.frame%enemy3CreateTime===0){
      if (!this.isInitEnemyNumer){
         this.createEnemyCount=rnd(6,9)
         this.isInitEnemyNumer=true

         this.enemyBirthX=rnd(width*1/12,width*11/12)
         this.enemyBirthY=0
         let topX=0.001
         let topY=0.9
         let route=this.createRoute(topX,topY)
         this.enemyRoute={
           a:route.routeA,
           b:route.routeB,
           c:0,
           dx:0,
           speed:enemy3Speed,
           yBirth:this.enemyBirthY,
           xBirth:this.enemyBirthX
         }
         if (this.enemyBirthX==width){
           this.enemyRoute.speed*=-1
           this.enemyRoute.b*=-1
         }
      }
      this.createEnemyCount--
      if (this.createEnemyCount==0){
        this.isInitEnemyNumer=false
        this.isCreatingEnemy=false
      }
      //创建对象
      const enemy=databus.pool.getItemByClass('enemy3',Enemy3)

      let newRoute=Object.assign({},this.enemyRoute)

      enemy.init(
        this.enemyBirthX,
        this.enemyBirthY,
        newRoute,
        enemy3BulletSpeed
      )
      this.enemyBirthX=rnd(width*1/12,width*11/12)
      databus.enemys.push(enemy)
    }
  }

  // 全局碰撞检测
  collisionDetection() {
    const that = this
  //判断
  //子弹碰撞到敌人，消灭敌人

    databus.enemys.forEach((enemy) => {
      databus.heroBullets.forEach((item)=>{
        if (enemy.isCollideWith(item)){
          item.visible=false
          enemy.life--
          if (!enemy.isPlaying&&enemy.life==0){
            this.music.playExplosion()
            enemy.playAnimation()
          }
        }
      })
    })
    
    //碰撞到子弹，血量减少/游戏结束
    databus.bullets.forEach((bullet)=>{
      if (this.player.isCollideWith(bullet)){
        databus.gameOver=true
      }
    })

    databus.enemys.forEach((enemy)=>{
      if (this.player.isCollideWith(enemy)){
        databus.gameOver=true
      }
    })
  }

  // 游戏结束后的触摸事件处理逻辑
  touchEventHandler(e) {
    e.preventDefault()

    const x = e.touches[0].clientX
    const y = e.touches[0].clientY

    const area = this.gameinfo.btnArea

    if (x >= area.startX
        && x <= area.endX
        && y >= area.startY
        && y <= area.endY) this.restart()
  }

  /**
   * canvas重绘函数
   * 每一帧重新绘制所有的需要展示的元素
   */
  render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    this.bg.render(ctx)

    this.player.drawToCanvas(ctx)

    //子弹和敌人绘制
    databus.bullets.
    forEach((item)=>{
      item.drawToCanvas(ctx)
    })

    databus.enemys.forEach((item)=>{
      item.drawToCanvas(ctx)
    })

    databus.heroBullets.forEach((item)=>{
      item.drawToCanvas(ctx)
    })

    databus.animations.
      forEach((ani) => {
      if (ani.isPlaying) {
        ani.aniRender(ctx)
      }
    })

    this.gameinfo.renderGameInfo(ctx, databus.scoreSurvive,databus.scoreKill,databus.scoreKill+databus.scoreSurvive)

    // 游戏结束停止帧循环
    if (databus.gameOver) {
      this.gameinfo.renderGameOver(ctx, databus.scoreSurvive+databus.scoreKill)

      if (!this.hasEventBind) {
        this.hasEventBind = true
        this.touchHandler = this.touchEventHandler.bind(this)
        canvas.addEventListener('touchstart', this.touchHandler)
      }
    }
  }

  // 游戏逻辑更新主函数
  update() {
    if (databus.gameOver) return

    databus.bullets.
    concat(databus.enemys).
    forEach((item)=>{
      item.update()
    })
    
    databus.heroBullets.forEach((item)=>{
      item.update()
    })

    this.bg.update()
    this.player.update()
    this.collisionDetection()

    //敌人生成
    this.enemyGenerate()

   if (databus.frame%enemyShootTime===0){
      databus.enemys.forEach((item)=>{
          item.shoot()
      })
    }

    if (databus.frame%heroShootTime===0){
      this.music.playShoot()
      this.player.shoot()
    }
  }

  // 实现游戏帧循环
  loop(timestamp) {
    if (!lastFrameTime) {
      lastFrameTime = timestamp;
    }
    
    // 计算时间间隔
    const deltaTime = timestamp - lastFrameTime;
    
    // 检查是否需要更新动画
    if (deltaTime > frameInterval) {
      databus.frame++
      if (!databus.gameOver){
        databus.scoreSurvive++
      }
      this.update()
      this.render()
      
      // 重置上一帧时间
      lastFrameTime = timestamp - (deltaTime % (frameInterval));
    }

      this.aniId = window.requestAnimationFrame(
        this.bindLoop,canvas
      )
  }
}
