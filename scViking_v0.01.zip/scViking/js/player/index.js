import Sprite from '../base/sprite'
import * as BGInfo from '../runtime/background'
import DataBus from '../databus'
import HeroBullet from '../player/heroBullet'

const databus=new DataBus()

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

// 玩家相关常量设置
const PLAYER_IMG_SRC = 'images/hero.png'
const PLAYER_WIDTH = BGInfo.IMG_WIDTH/5
const PLAYER_WIDTH_TURN=PLAYER_WIDTH*5/8
const PLAYER_HEIGHT = PLAYER_WIDTH*1

const DEFAULT_SPEED=BGInfo.IMG_WIDTH/75
const BULLET_SPEED=-BGInfo.IMG_HEIGHT/60

export let touch_x,touch_y,touch_endx,touch_endy

let isMoving,speedPlayer,speedBg

let touchStartX,touchStartY

export {isMoving,speedPlayer,speedBg,speed,PLAYER_WIDTH,PLAYER_HEIGHT}

let speed=function(dx,dy,speed){
  if (dx*dx+dy*dy==0){
    return{
      sx:0,
      sy:0
    }
  }
  let multi=speed/Math.sqrt(dx*dx+dy*dy)
  return {
    sx:dx*multi,
    sy:dy*multi
  }
}

export default class Player extends Sprite {
  constructor() {
    super(PLAYER_IMG_SRC, PLAYER_WIDTH, PLAYER_HEIGHT)

    // 玩家默认处于屏幕中间
    this.x = screenWidth / 2 - this.width / 2
    this.y = screenHeight / 2 - this.height / 2

    this.shootMethod=0

    this.speed=DEFAULT_SPEED

    // 初始化事件监听
    this.initEvent()
  }

  update(){
    let x=0.0,y=0.0
    x=screenWidth*(BGInfo.player_X-BGInfo.lt_X)/BGInfo.IMG_WIDTH-this.width/2
    y=screenHeight*(BGInfo.player_Y-BGInfo.lt_Y)/BGInfo.IMG_HEIGHT-this.height/2
    this.setAirPos(x,y)
  }

  /**
   * 设置飞机的位置
   * 限定飞机的活动范围限制在屏幕中
   */
  setAirPos(x, y) {
    let disX = x 
    let disY = y 

    if (disX < 0) disX = 0

    else if (disX > screenWidth - this.width) disX = screenWidth - this.width

    if (disY < 0) disY = 0

    else if (disY > screenHeight - this.height) disY = screenHeight - this.height

    this.x = disX
    this.y = disY
  }

  /**
   * 玩家响应手指的触摸事件
   */
  initEvent() {

    canvas.addEventListener('touchstart', ((e) => {
      e.preventDefault()

      isMoving=true
      const x = e.touches[0].clientX
      const y = e.touches[0].clientY

      touchStartX=x
      touchStartY=y

      touch_x=x
      touch_y=y
      
      speedPlayer=speed(x-this.x,y-this.y,this.speed)

      this.shoot()
    }))

    canvas.addEventListener('touchmove', ((e) => {
      e.preventDefault()

      const x = e.touches[0].clientX
      const y = e.touches[0].clientY

      touch_endx=x
      touch_endy=y

      if (touch_endx<touch_x){
        this.img.src="images/hero_left.png"
      }
      
      else if (touch_endx>touch_x){
        this.img.src="images/hero_right.png"
      }
      this.width=PLAYER_WIDTH_TURN
      speedPlayer=speed(x-touchStartX,y-touchStartY,this.speed)
    }))

    canvas.addEventListener('touchend', ((e) => {

      touch_x=0
      touch_y=0
      touch_endx=0
      touch_endy=0

      e.preventDefault()

      this.img.src="images/hero.png"
      this.width=PLAYER_WIDTH
       
      isMoving=false

    }))
  }

  shoot(){
    if (this.shootMethod===0){
      const bullet=databus.pool.getItemByClass('heroBullet',HeroBullet)
      
      bullet.init(
        BGInfo.player_X,
        BGInfo.player_Y-this.height/2,
        {
          sx:0,
          sy:BULLET_SPEED
        }
      )

      databus.heroBullets.push(bullet)
    }
  }
}
