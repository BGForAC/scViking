import Sprite from '../base/sprite'
import Databus from '../databus'
import * as BGInfo from '../runtime/background'

const BULLET_WIDTH=BGInfo.IMG_WIDTH/10
const BULLET_HEIGHT=BULLET_WIDTH

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

const BULLET_IMG_SRC='images/heroBullet.png'

const databus=new Databus()

let _={
  speed:Symbol('speed')
}

export default class HeroBullet extends Sprite{
  constructor(){
    super(BULLET_IMG_SRC,BULLET_WIDTH,BULLET_HEIGHT)
  }

  init(x,y,speed){
    this.realX=x
    this.realY=y
    this.x=screenWidth*(this.realX-BGInfo.lt_X)/BGInfo.IMG_WIDTH-this.width/2
    this.y=screenHeight*(this.realY-BGInfo.lt_Y)/BGInfo.IMG_HEIGHT-this.height/2
    this[_.speed]=speed
    this.visible=true
  }

  update(){
    this.realX+=this[_.speed].sx
    this.realY+=this[_.speed].sy
    this.x=screenWidth*(this.realX-BGInfo.lt_X)/BGInfo.IMG_WIDTH-this.width/2
    this.y=screenHeight*(this.realY-BGInfo.lt_Y)/BGInfo.IMG_HEIGHT-this.height/2
    if (this.realX<0||this.realX>BGInfo.BG_WIDTH||this.realY<0||this.realY>BGInfo.BG_HEIGHT||this.visible==false){
      databus.removeHeroBullets(this)
    }
  }
}