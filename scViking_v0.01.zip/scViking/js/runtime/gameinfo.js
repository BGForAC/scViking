import * as index from '../player/index'
import * as BGInfo from './background'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

const atlas = new Image()
atlas.src = 'images/Common.png'

export default class GameInfo {
  renderGameInfo(ctx, scoreSurvive,scoreKill,score) {
    if (index.touch_x&&index.touch_y){
      ctx.beginPath();
      ctx.arc(index.touch_x, index.touch_y, BGInfo.IMG_WIDTH/10, 0, Math.PI * 2, false);
      ctx.fillStyle='rgba(255,255,255,0.2)'
      ctx.fill();
    }

    if (index.touch_endx&&index.touch_endy){
      ctx.beginPath();
      ctx.arc(index.touch_endx,index.touch_endy,BGInfo.IMG_WIDTH/30,0,Math.PI*2,false);
      ctx.fillStyle='rgba(255,255,255,0.2)'
      ctx.fill();
    }

    if (index.touch_x&&index.touch_y&&index.touch_endx&&index.touch_endy){
      ctx.beginPath()
      ctx.moveTo(index.touch_x,index.touch_y)
      ctx.lineTo(index.touch_endx,index.touch_endy)
      ctx.closePath()
      ctx.strokeStyle='rgba(255,255,255,0.2)'
      ctx.stroke();
    }

    ctx.fillStyle = '#ffffff'
    ctx.font = '20px Arial'

    ctx.fillText(
      '生存得分：'+scoreSurvive,
      10,
      30
    )

    ctx.fillText(
      '击杀得分：'+scoreKill,
      10,
      50
    )

    ctx.fillText(
      '总得分：'+score,
      10,
      70
    )

    

  }

  renderGameOver(ctx, score) {
    ctx.drawImage(atlas, 0, 0, 119, 108, screenWidth / 2 - 150, screenHeight / 2 - 100, 300, 300)

    ctx.fillStyle = '#ffffff'
    ctx.font = '20px Arial'

    ctx.fillText(
      '游戏结束',
      screenWidth / 2 - 40,
      screenHeight / 2 - 100 + 50
    )

    ctx.fillText(
      `得分: ${score}`,
      screenWidth / 2 - 40,
      screenHeight / 2 - 100 + 130
    )

    ctx.drawImage(
      atlas,
      120, 6, 39, 24,
      screenWidth / 2 - 60,
      screenHeight / 2 - 100 + 180,
      120, 40
    )

    ctx.fillText(
      '重新开始',
      screenWidth / 2 - 40,
      screenHeight / 2 - 100 + 205
    )

    /**
     * 重新开始按钮区域
     * 方便简易判断按钮点击
     */
    this.btnArea = {
      startX: screenWidth / 2 - 40,
      startY: screenHeight / 2 - 100 + 180,
      endX: screenWidth / 2 + 50,
      endY: screenHeight / 2 - 100 + 255
    }
  }
}
