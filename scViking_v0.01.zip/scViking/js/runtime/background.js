import Sprite from '../base/sprite'
import DataBus from '../databus'
import * as index from '../player/index'

const databus=new DataBus

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

const BG_IMG_SRC = 'images/bg.jpg'
//背景大小
const BG_WIDTH = screenWidth*2
const BG_HEIGHT = screenHeight*2
//每次呈现的截图大小
const IMG_WIDTH=screenWidth
const IMG_HEIGHT=screenHeight

const initPosition_x=0.5,initPosition_y=0.8

let lt_X=(BG_WIDTH-IMG_WIDTH)*initPosition_x,lt_Y=(BG_HEIGHT-IMG_HEIGHT)*initPosition_y,isLock=true

let player_X=BG_WIDTH*initPosition_x,player_Y=BG_HEIGHT*initPosition_y

let BGSpeed_press=IMG_WIDTH/75,BGSpeed_release=IMG_WIDTH/100

export{isLock,player_X,player_Y,lt_X,lt_Y,IMG_HEIGHT,IMG_WIDTH,BG_HEIGHT,BG_WIDTH}

/**
 * 游戏背景类
 */
export default class BackGround extends Sprite {
  constructor(ctx) {
    super(BG_IMG_SRC, BG_WIDTH, BG_HEIGHT)

    this.top = 0

    this.PLAYER_WIDTH_IN_BG=index.PLAYER_WIDTH
    this.PLAYER_HEIGHT_IN_BG=index.PLAYER_HEIGHT

    this.render(ctx)
  }
  
  //设置图片位置
  setImgPos(x,y){
    if (x<0) lt_X=0
    else if (x>BG_WIDTH-IMG_WIDTH)   lt_X=BG_WIDTH-IMG_WIDTH
    else  lt_X=x

    if (y<0) lt_Y=0
    else if (y>BG_HEIGHT-IMG_HEIGHT)  lt_Y=BG_HEIGHT-IMG_HEIGHT
    else  lt_Y=y
  }

  //判断是否处于中心位置
  isCenter(){
    if (Math.abs(lt_X+IMG_WIDTH/2-player_X)<1
     && Math.abs(lt_Y+IMG_HEIGHT/2-player_Y)<1) {
      return true
    }
    return false
  }

  update() {
    
   if (index.isMoving||!isLock){
     if (index.isMoving){
      player_X+=index.speedPlayer.sx
      //防止越界
      if (player_X<this.PLAYER_WIDTH_IN_BG/2) player_X=this.PLAYER_WIDTH_IN_BG/2
      else if (player_X>BG_WIDTH-this.PLAYER_WIDTH_IN_BG/2) player_X=BG_WIDTH-this.PLAYER_WIDTH_IN_BG/2

      player_Y+=index.speedPlayer.sy
      //防止越界
      if (player_Y<this.PLAYER_HEIGHT_IN_BG/2) player_Y=this.PLAYER_HEIGHT_IN_BG/2
      else if (player_Y>BG_HEIGHT-this.PLAYER_HEIGHT_IN_BG/2) player_Y=BG_HEIGHT-this.PLAYER_HEIGHT_IN_BG/2
     }

     //设定背景移动速度
     index.speedBg=index.speed(player_X-lt_X-IMG_WIDTH/2,player_Y-lt_Y-IMG_HEIGHT/2,BGSpeed_press)
     if (!index.isMoving){
      index.speedBg=index.speed(player_X-lt_X-IMG_WIDTH/2,player_Y-lt_Y-IMG_HEIGHT/2,BGSpeed_release)
     }

     this.setImgPos(lt_X+index.speedBg.sx,lt_Y+index.speedBg.sy)
     if (lt_X==0||lt_X==BG_WIDTH-IMG_WIDTH||lt_Y==0||lt_Y==BG_HEIGHT-IMG_HEIGHT||this.isCenter()) {
       isLock=true;
     }else{
       isLock=false;
     }

   }
  }

  render(ctx) {
    ctx.drawImage(
      this.img,
      lt_X,
      lt_Y,
      IMG_WIDTH,
      IMG_HEIGHT,
      0,
      0,
      screenWidth,
      screenHeight
    )
  }
}
